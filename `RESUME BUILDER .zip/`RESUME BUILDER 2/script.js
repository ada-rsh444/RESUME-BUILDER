document.addEventListener('DOMContentLoaded', () => {
    const signupForm = document.getElementById('signupForm');
    const loginForm = document.getElementById('loginForm');

    // Handle signup form submission
    if (signupForm) {
        signupForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const username = document.getElementById('signupUsername').value;
            const password = document.getElementById('signupPassword').value;

            localStorage.setItem('username', username);
            localStorage.setItem('password', password);

            alert('Sign up successful! Please login.');
            window.location.href = 'login.html';
        });
    }

    // Handle login form submission
    if (loginForm) {
        loginForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const username = document.getElementById('loginUsername').value;
            const password = document.getElementById('loginPassword').value;

            const storedUsername = localStorage.getItem('username');
            const storedPassword = localStorage.getItem('password');

            if (username === storedUsername && password === storedPassword) {
                alert('Login successful!');
                window.location.href = 'resume_builder.html';
            } else {
                alert('Invalid username or password');
            }
        });
    }
});

// Export resume function
function exportResume(format) {
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const summary = document.getElementById('summary').value;
    const education = document.getElementById('education').value;
    const experience = document.getElementById('experience').value;

    let resumeContent = `
        <h1>${name}</h1>
        <p>${email}</p>
        <h2>Summary</h2>
        <p>${summary}</p>
        <h2>Education</h2>
        <p>${education}</p>
        <h2>Experience</h2>
        <p>${experience}</p>
    `;

    if (format === 'pdf') {
        // For PDF export
        let pdfWindow = window.open('', '', 'width=800,height=900');
        pdfWindow.document.write(resumeContent);
        pdfWindow.document.close();
        pdfWindow.print();
    } else if (format === 'docx') {
        // For DOCX export
        let blob = new Blob([resumeContent], { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
        let link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.download = 'resume.docx';
        link.click();
    }
}
